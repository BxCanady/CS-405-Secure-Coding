// NumericOverflows.cpp : This file contains the 'main' function.
// Program execution begins and ends there.
//

#include <iostream>     // std::cout
#include <limits>       // std::numeric_limits
#include <optional>     // std::optional, std::nullopt
#include <type_traits>  // std::is_signed_v
#include <typeinfo>     // typeid
#include <string>       // std::string

#if !defined(__cpp_lib_optional) && (!defined(_MSVC_LANG) || _MSVC_LANG < 201703L)
namespace std {
    struct nullopt_t {
        struct init {};
        constexpr explicit nullopt_t(init) {}
    };
    constexpr nullopt_t nullopt{nullopt_t::init{}};

    template <typename T>
    class optional {
    public:
        optional() : m_has_value(false) {}
        optional(nullopt_t) : m_has_value(false) {}
        optional(T const& value) : m_has_value(true), m_value(value) {}

        bool has_value() const { return m_has_value; }
        T const& value() const { return m_value; }
        T& value() { return m_value; }

        optional& operator=(optional const& other) {
            m_has_value = other.m_has_value;
            if (m_has_value) {
                m_value = other.m_value;
            }
            return *this;
        }

    private:
        bool m_has_value;
        T m_value;
    };
}
#endif

template <typename T>
bool check_add_overflow(T const& result, T const& increment, std::true_type)
{
    if (increment > 0 &&
        result > std::numeric_limits<T>::max() - increment)
    {
        return true;
    }
    if (increment < 0 &&
        result < std::numeric_limits<T>::lowest() - increment)
    {
        return true;
    }
    return false;
}

template <typename T>
bool check_add_overflow(T const& result, T const& increment, std::false_type)
{
    if (increment > 0 &&
        result > std::numeric_limits<T>::max() - increment)
    {
        return true;
    }
    return false;
}

template <typename T>
bool check_subtract_underflow(T const& result, T const& decrement, std::true_type)
{
    if (decrement > 0 &&
        result < std::numeric_limits<T>::lowest() + decrement)
    {
        return true;
    }
    if (decrement < 0 &&
        result > std::numeric_limits<T>::max() + decrement)
    {
        return true;
    }
    return false;
}

template <typename T>
bool check_subtract_underflow(T const& result, T const& decrement, std::false_type)
{
    if (result < decrement)
    {
        return true;
    }
    return false;
}


/// <summary>
/// Adds a number to itself a specified number of times.
///
/// The function checks BEFORE doing each addition to make sure
/// the result will fit inside the data type.
///
/// If the addition would cause an overflow, std::nullopt is returned.
/// Otherwise, the calculated value is returned.
/// </summary>
/// <typeparam name="T">The numeric data type being used.</typeparam>
/// <param name="start">The number to start with.</param>
/// <param name="increment">How much to add each step.</param>
/// <param name="steps">The number of times to add.</param>
/// <returns>
/// The calculated value if successful, or std::nullopt if overflow occurs.
/// </returns>
template <typename T>
std::optional<T> add_numbers(
    T const& start,
    T const& increment,
    unsigned long int const& steps)
{
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Before adding, make sure the addition will not go
        // beyond the largest value that T can hold.
        if (check_add_overflow(result, increment, typename std::is_signed<T>::type()))
        {
            return std::nullopt;
        }

        // We know the addition is safe, so perform it.
        result += increment;
    }

    // Return the successful result.
    return result;
}


/// <summary>
/// Subtracts a number from itself a specified number of times.
///
/// The function checks BEFORE doing each subtraction to make sure
/// the result will fit inside the data type.
///
/// If the subtraction would cause an underflow, std::nullopt is returned.
/// Otherwise, the calculated value is returned.
/// </summary>
/// <typeparam name="T">The numeric data type being used.</typeparam>
/// <param name="start">The number to start with.</param>
/// <param name="decrement">How much to subtract each step.</param>
/// <param name="steps">The number of times to subtract.</param>
/// <returns>
/// The calculated value if successful, or std::nullopt if underflow occurs.
/// </returns>
template <typename T>
std::optional<T> subtract_numbers(
    T const& start,
    T const& decrement,
    unsigned long int const& steps)
{
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Before subtracting, make sure the subtraction will not
        // go below the smallest value that T can hold.
        if (check_subtract_underflow(result, decrement, typename std::is_signed<T>::type()))
        {
            return std::nullopt;
        }

        // We know the subtraction is safe, so perform it.
        result -= decrement;
    }

    // Return the successful result.
    return result;
}


// NOTE:
// You will see the unary ('+') operator used in front of the variables
// in the test_XXX methods.
// This forces the output to be a number for cases where cout would
// assume it is a character.

template <typename T>
void test_overflow()
{
    // START DO NOT CHANGE
    // how many times will we iterate
    const unsigned long int steps = 5;

    // how much will we add each step
    // result should be: start + (increment * steps)
    const T increment = std::numeric_limits<T>::max() / steps;

    // whats our starting point
    const T start = 0;

    std::cout << "Overflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE


    std::cout << "\tAdding Numbers Without Overflow ("
        << +start << ", "
        << +increment << ", "
        << steps
        << ") = ";

    // add_numbers now returns an optional value.
    // If the calculation succeeds, it contains the result.
    // If an overflow occurs, it contains nothing.
    auto result = add_numbers<T>(start, increment, steps);

    if (result.has_value())
    {
        // The calculation was successful.
        std::cout << +result.value() << std::endl;
    }
    else
    {
        // The calculation failed because of overflow.
        std::cout << "Overflow detected!" << std::endl;
    }


    std::cout << "\tAdding Numbers With Overflow ("
        << +start << ", "
        << +increment << ", "
        << (steps + 1)
        << ") = ";

    result = add_numbers<T>(start, increment, steps + 1);

    if (result.has_value())
    {
        // The calculation unexpectedly fit inside the data type.
        std::cout << +result.value() << std::endl;
    }
    else
    {
        // The function detected the overflow BEFORE it happened.
        std::cout << "Overflow detected!" << std::endl;
    }
}


template <typename T>
void test_underflow()
{
    // START DO NOT CHANGE
    // how many times will we iterate
    const unsigned long int steps = 5;

    // how much will we subtract each step
    // result should be: start - (increment * steps)
    const T decrement = std::numeric_limits<T>::max() / steps;

    // whats our starting point
    const T start = std::numeric_limits<T>::max();

    std::cout << "Underflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE


    std::cout << "\tSubtracting Numbers Without Overflow ("
        << +start << ", "
        << +decrement << ", "
        << steps
        << ") = ";

    // subtract_numbers now returns an optional value.
    auto result = subtract_numbers<T>(start, decrement, steps);

    if (result.has_value())
    {
        // The subtraction was successful.
        std::cout << +result.value() << std::endl;
    }
    else
    {
        // The subtraction failed because of underflow.
        std::cout << "Underflow detected!" << std::endl;
    }


    std::cout << "\tSubtracting Numbers With Overflow ("
        << +start << ", "
        << +decrement << ", "
        << (steps + 1)
        << ") = ";

    result = subtract_numbers<T>(start, decrement, steps + 1);

    if (result.has_value())
    {
        // The calculation was successful.
        std::cout << +result.value() << std::endl;
    }
    else
    {
        // The function detected the underflow BEFORE it happened.
        std::cout << "Underflow detected!" << std::endl;
    }
}


void do_overflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Overflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primitive types
    // See: https://www.geeksforgeeks.org/c-data-types/

    // signed integers
    test_overflow<char>();
    test_overflow<wchar_t>();
    test_overflow<short int>();
    test_overflow<int>();
    test_overflow<long>();
    test_overflow<long long>();

    // unsigned integers
    test_overflow<unsigned char>();
    test_overflow<unsigned short int>();
    test_overflow<unsigned int>();
    test_overflow<unsigned long>();
    test_overflow<unsigned long long>();

    // real numbers
    test_overflow<float>();
    test_overflow<double>();
    test_overflow<long double>();
}


void do_underflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Undeflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primitive types
    // See: https://www.geeksforgeeks.org/c-data-types/

    // signed integers
    test_underflow<char>();
    test_underflow<wchar_t>();
    test_underflow<short int>();
    test_underflow<int>();
    test_underflow<long>();
    test_underflow<long long>();

    // unsigned integers
    test_underflow<unsigned char>();
    test_underflow<unsigned short int>();
    test_underflow<unsigned int>();
    test_underflow<unsigned long>();
    test_underflow<unsigned long long>();

    // real numbers
    test_underflow<float>();
    test_underflow<double>();
    test_underflow<long double>();
}


/// <summary>
/// Entry point into the application
/// </summary>
/// <returns>0 when complete</returns>
int main()
{
    // create a string of "*" to use in the console
    const std::string star_line = std::string(50, '*');

    std::cout << "Starting Numeric Underflow / Overflow Tests!" << std::endl;

    // run the overflow tests
    do_overflow_tests(star_line);

    // run the underflow tests
    do_underflow_tests(star_line);

    std::cout << std::endl
        << "All Numeric Underflow / Overflow Tests Complete!"
        << std::endl;

    return 0;
}


// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu